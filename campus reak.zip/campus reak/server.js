const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ✅ Middleware: CORS
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));

// ✅ Middleware: Body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Middleware: Session
app.use(session({
  secret: 'secretkey',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: false,
    sameSite: 'lax',
    path: '/'
  }
}));

// ✅ 🔐 Block dashboard if not logged in
app.use((req, res, next) => {
  const protected = ['/admin-dashboard.html', '/student-dashboard.html'];
  if (protected.includes(req.url) && !req.session.user) {
    return res.redirect('/');
  }
  next();
});

// ✅ Auth check middleware
function isAuthenticated(req, res, next) {
  if (req.session.user) return next();
  res.redirect('/');
}
function isAdmin(req, res, next) {
  if (req.session.user?.role === 'admin') return next();
  res.redirect('/');
}
function isStudent(req, res, next) {
  if (req.session.user?.role === 'student') return next();
  res.redirect('/');
}

// ✅ Routes: Pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});
app.get('/admin-dashboard.html', isAuthenticated, isAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'admin-dashboard.html'));
});
app.get('/student-dashboard.html', isAuthenticated, isStudent, (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'student-dashboard.html'));
});

// ✅ Static Files
app.use(express.static(path.join(__dirname, 'frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ✅ Routes: APIs
app.use('/api', require('./backend/routes/auth.routes'));          // /api/login, /api/logout
app.use('/api/events', require('./backend/routes/event.routes'));  // /api/events/*
app.use('/api/student', require('./backend/routes/student.routes'));// /api/student/registrations etc.

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});

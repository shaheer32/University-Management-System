// backend/controllers/student.controller.js
exports.registerForEvent = async (req, res) => {
  const { eventId } = req.body;
  const userId = req.session.user?.id;

  if (!userId || !eventId) {
    return res.status(400).json({ message: 'Missing user or event ID' });
  }

  try {
    const db = require('../../db'); // ✅ Make sure your db connection is correct
    await db.execute(
      'INSERT INTO registrations (student_id, event_id, status) VALUES (?, ?, ?)',
      [userId, eventId, 'pending']
    );

    res.json({ message: '✅ Registration submitted!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: '❌ Failed to register' });
  }
};

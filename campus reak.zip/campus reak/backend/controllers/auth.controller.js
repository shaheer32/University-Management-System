const conn = require('../models/db');
const bcrypt = require('bcrypt');

// REGISTER
exports.register = (req, res) => {
  const { name, email, password, role } = req.body;

  // Validation
  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  if (!email.endsWith('@gmail.com')) {
    return res.status(400).json({ message: 'Email must be a @gmail.com' });
  }

  if (password.length < 8) {
    return res.status(400).json({ message: 'Password must be at least 8 characters long' });
  }

  // Check if email exists first
  const checkSql = 'SELECT * FROM users WHERE email = ?';
  conn.query(checkSql, [email], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length > 0) {
      return res.status(409).json({ message: 'Email already exists' });
    }

    // If not exist, proceed
    bcrypt.hash(password, 10, (err, hash) => {
      if (err) return res.status(500).json({ message: 'Hashing error' });
console.log('Registering:', { name, email, password, role });

      const insertSql = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
      conn.query(insertSql, [name, email, hash, role], (err) => {
        if (err) return res.status(500).json({ message: 'Database insert error' });

        res.status(200).json({ message: 'Registration successful. Please login.' });
      });
    });
  });
};

// LOGIN
exports.login = (req, res) => {
  const { email, password, role } = req.body;

  if (!email || !password || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const sql = 'SELECT * FROM users WHERE email = ? AND role = ?';
  conn.query(sql, [email, role], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid email or role' });
    }

    const user = results[0];
    bcrypt.compare(password, user.password, (err, match) => {
      if (err) return res.status(500).json({ message: 'Server error' });
      if (!match) return res.status(401).json({ message: 'Incorrect password' });

      res.status(200).json({
        message: 'Login successful',
        role: user.role
      });
    });
  });
};

const mysql = require('mysql2');

const conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'EventManagement' // ✅ Make sure this name matches exactly!
});

conn.connect((err) => {
  if (err) {
    console.error('MySQL connection error:', err.message);
    return;
  }
  console.log('✅ Connected to MySQL');
});

module.exports = conn;

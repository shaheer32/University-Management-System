// const express = require('express');
// const router = express.Router();
// const conn = require('../models/db');

// // ✅ Register without password hashing
// router.post('/register', (req, res) => {
//   const { name, email, password, role } = req.body;

//   if (!name || !email || !password || !role) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

//   const roleLower = role.toLowerCase();
//   const checkSql = 'SELECT * FROM users WHERE email = ?';

//   conn.query(checkSql, [email], (err, results) => {
//     if (err) return res.status(500).json({ message: 'Database error' });
//     if (results.length > 0) return res.status(409).json({ message: 'Email already exists' });

//     const insertSql = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
//     conn.query(insertSql, [name, email, password, roleLower], (err) => {
//       if (err) return res.status(500).json({ message: 'Error saving user' });
//       res.status(200).json({ message: 'Registration successful' });
//     });
//   });
// });

// // ✅ Login (plaintext password check)
// router.post('/login', (req, res) => {
//   const { email, password, role } = req.body;
//   const roleLower = role.toLowerCase();

//   console.log('🟡 Login attempt:', { email, password, role: roleLower });

//   if (!email || !password || !roleLower) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

//   const sql = 'SELECT * FROM users WHERE email = ? AND role = ?';
//   conn.query(sql, [email, roleLower], (err, results) => {
//     if (err) return res.status(500).json({ message: 'Database error' });

//     if (results.length === 0) {
//       console.log('❌ No matching user for role:', roleLower);
//       return res.status(401).json({ message: 'User not found or role mismatch' });
//     }

//     const user = results[0];
//     console.log('🔍 DB password:', user.password);
//     console.log('🔍 Input password:', password);

//     if (user.password !== password) {
//       console.log('❌ Password mismatch');
//       return res.status(401).json({ message: 'Incorrect password' });
//     }

//     req.session.user = {
//       id: user.id,
//       name: user.name,
//       role: roleLower
//     };

//     console.log('✅ Session started:', req.session.user);

//     res.status(200).json({
//       message: 'Login successful',
//       role: roleLower
//     });
//   });
// });

// // ✅ Get session user
// router.get('/me', (req, res) => {
//   console.log('🔍 Session check:', req.session.user); // ADD THIS LINE
//   if (req.session.user) {
//     return res.json({
//       name: req.session.user.name,
//       role: req.session.user.role
//     });
//   }
//   res.status(401).json({ message: 'Not logged in' });
// });


// // ✅ Logout
// router.post('/logout', (req, res) => {
//   req.session.destroy(() => {
//     res.clearCookie('connect.sid');
//     console.log('🚪 Logged out');
//     res.status(200).json({ message: 'Logged out' });
//   });
// });

// module.exports = router;
// backend/routes/auth.routes.js

const express = require('express');
const router  = express.Router();
const conn    = require('../models/db');
const bcrypt  = require('bcrypt');

/**
 * POST /api/register
 * - Required: name, email (@gmail.com), password (min 8 chars), role
 * - Checks for duplicate email
 * - Hashes password with bcrypt
 * - Inserts new user
 */
router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  const roleLower = role?.toLowerCase?.();

  // 1) Validate presence
  if (!name || !email || !password || !roleLower) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // 2) Email domain check
  if (!email.endsWith('@gmail.com')) {
    return res.status(400).json({ message: 'Email must end with @gmail.com' });
  }

  // 3) Password length check
  if (password.length < 8) {
    return res.status(400).json({ message: 'Password must be at least 8 characters long' });
  }

  // 4) Duplicate-email check
  conn.query(
    'SELECT id FROM users WHERE email = ?',
    [email],
    (err, results) => {
      if (err) {
        console.error('Email lookup error:', err);
        return res.status(500).json({ message: 'Database error' });
      }
      if (results.length > 0) {
        return res.status(409).json({ message: 'Email already exists' });
      }

      // 5) Hash the password
      bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
          console.error('Hashing error:', err);
          return res.status(500).json({ message: 'Error securing password' });
        }

        // 6) Insert new user
        conn.query(
          'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
          [name, email, hash, roleLower],
          err => {
            if (err) {
              console.error('User insert error:', err);
              return res.status(500).json({ message: 'Error saving user' });
            }
            return res
              .status(201)
              .json({ message: 'Registration successful. Please log in.' });
          }
        );
      });
    }
  );
});

/**
 * POST /api/login
 * - Required: email, password, role
 * - Fetches user by email+role
 * - bcrypt.compare submitted vs stored hash
 * - On success, saves user in session
 */
router.post('/login', (req, res) => {
  const { email, password, role } = req.body;
  const roleLower = role?.toLowerCase?.();

  // 1) Validate presence
  if (!email || !password || !roleLower) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // 2) Fetch user
  conn.query(
    'SELECT * FROM users WHERE email = ? AND role = ?',
    [email, roleLower],
    (err, results) => {
      if (err) {
        console.error('Login lookup error:', err);
        return res.status(500).json({ message: 'Database error' });
      }
      if (results.length === 0) {
        return res.status(401).json({ message: 'Invalid email or role' });
      }

      const user = results[0];

      // 3) Compare passwords
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error('Compare error:', err);
          return res.status(500).json({ message: 'Authentication error' });
        }
        if (!isMatch) {
          return res.status(401).json({ message: 'Incorrect password' });
        }

        // 4) Save to session
        req.session.user = {
          id:   user.id,
          name: user.name,
          role: user.role
        };
        console.log('✅ Logged in:', req.session.user);

        return res
          .status(200)
          .json({ message: 'Login successful', role: user.role });
      });
    }
  );
});

/**
 * GET /api/me
 * - Returns the logged-in user (if any)
 */
router.get('/me', (req, res) => {
  if (req.session?.user) {
    return res.status(200).json({
      name: req.session.user.name,
      role: req.session.user.role
    });
  }
  return res.status(401).json({ message: 'Not logged in' });
});

/**
 * POST /api/logout
 * - Destroys session and clears cookie
 */
router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({ message: 'Logout failed' });
    }
    res.clearCookie('connect.sid');
    console.log('🚪 User logged out');
    return res.status(200).json({ message: 'Logged out successfully' });
  });
});

module.exports = router;

const express = require('express');
const router = express.Router();
const conn = require('../models/db');

// ✅ Register for Event
router.post('/register-event', (req, res) => {
  const {
    student_name, email, department,
    roll_no, age, gender, phone, event_id
  } = req.body;

  if (!student_name || !email || !department || !roll_no || !age || !gender || !phone || !event_id) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const sql = `
    INSERT INTO student_registrations
    (student_name, email, department, roll_no, age, gender, phone, event_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;
  const values = [student_name, email, department, roll_no, age, gender, phone, event_id];

  conn.query(sql, values, (err) => {
    if (err) {
      console.error('SQL Error:', err);
      return res.status(500).json({ message: 'Database error' });
    }
    res.status(200).json({ message: 'Registration submitted successfully!' });
  });
});

// ✅ Admin: Get all student registrations with event details
router.get('/registrations', (req, res) => {
  const sql = `
    SELECT sr.*, e.event_name AS event_title, e.start_date, e.end_date, e.start_time, e.end_time, e.venue
    FROM student_registrations sr
    JOIN events e ON sr.event_id = e.id
    ORDER BY sr.registered_at DESC
  `;
  conn.query(sql, (err, results) => {
    if (err) {
      console.error('SQL Error:', err);
      return res.status(500).json({ message: 'Database error', error: err });
    }
    res.status(200).json(results);
  });
});



// ✅ Admin: Update status
router.put('/registrations/:id', (req, res) => {
  const { status } = req.body;
  const { id } = req.params;

  if (!['Pending', 'Approved', 'Denied'].includes(status)) {
    return res.status(400).json({ message: 'Invalid status' });
  }

  const sql = `UPDATE student_registrations SET status = ? WHERE id = ?`;
  conn.query(sql, [status, id], (err) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    res.json({ message: 'Status updated successfully' });
  });
});

// ✅ Student: View own registrations
router.get('/my-registrations', async (req, res) => {
  if (!req.session?.user?.email) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const email = req.session.user.email;

  const sql = `
    SELECT sr.*, e.event_name AS event_title, e.start_date, e.end_date, e.start_time, e.end_time, e.venue
    FROM student_registrations sr
    JOIN events e ON sr.event_id = e.id
    WHERE sr.email = ?
    ORDER BY sr.created_at DESC
  `;

  conn.query(sql, [email], (err, results) => {
    if (err) {
      console.error('My registrations fetch error:', err);
      return res.status(500).json({ message: 'Database error' });
    }
    res.status(200).json(results);
  });
});

module.exports = router;

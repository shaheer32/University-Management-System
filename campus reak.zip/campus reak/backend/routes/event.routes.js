// backend/routes/event.routes.js
// ------------------------------
// Express router for event CRUD operations, including multipart image upload,
// dynamic validation on creation, and partial updates with optional image replacement or deletion.

const express = require('express');
const router  = express.Router();
const path    = require('path');
const multer  = require('multer');
const conn    = require('../models/db'); // MySQL connection instance

// Multer setup: store files in ./uploads with unique filenames
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, './uploads/'),
  filename:    (req, file, cb) => {
    const uniqueName = Date.now() + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

// ─── POST /api/events ───────────────────────────────────────
// Create a new event. All fields including image and created_by are mandatory.
router.post('/', upload.single('image'), (req, res) => {
  try {
    const {
      event_name, start_date, end_date,
      start_time, end_time, venue,
      description, created_by
    } = req.body;
    const image = req.file?.filename;

    // 1) Validate mandatory fields
    if (!event_name || !start_date || !end_date ||
        !start_time || !end_time   || !venue    ||
        !description || !created_by || !image) {
      return res.status(400).json({ message: 'All fields including image are required.' });
    }

    // 2) Insert into database
    const sql = `
      INSERT INTO events
        (event_name, start_date, end_date, start_time, end_time, venue, description, image, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    conn.query(sql,
      [event_name, start_date, end_date, start_time, end_time, venue, description, image, created_by],
      err => {
        if (err) {
          console.error('Error creating event:', err);
          return res.status(500).json({ message: 'Database error.' });
        }
        res.status(201).json({ message: 'Event created successfully.' });
      }
    );
  } catch (err) {
    console.error('Unhandled error in POST /api/events:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── GET /api/events ────────────────────────────────────────
// Fetch all events, sorted by date and time
router.get('/', (req, res) => {
  const sql = 'SELECT * FROM events ORDER BY start_date ASC, start_time ASC';
  conn.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching events:', err);
      return res.status(500).json({ message: 'Failed to fetch events.' });
    }
    res.json(results);
  });
});

// ─── PUT /api/events/:id ────────────────────────────────────
// Partial update of event. Accept any file field, then pick "image".
router.put('/:id', upload.any(), (req, res) => {
  try {
    const { id } = req.params;
    const {
      event_name, start_date, end_date,
      start_time, end_time, venue,
      description, deleteImage
    } = req.body;

    // Find the uploaded “image” file (if any)
    const imageFile = (req.files || []).find(f => f.fieldname === 'image');
    const imageName = imageFile?.filename;

    // 1) Build dynamic update clauses
    const updates = [];
    const values  = [];
    if (event_name)  { updates.push('event_name = ?');  values.push(event_name); }
    if (start_date)  { updates.push('start_date = ?');  values.push(start_date); }
    if (end_date)    { updates.push('end_date   = ?');  values.push(end_date); }
    if (start_time)  { updates.push('start_time = ?');  values.push(start_time); }
    if (end_time)    { updates.push('end_time   = ?');  values.push(end_time); }
    if (venue)       { updates.push('venue      = ?');  values.push(venue); }
    if (description) { updates.push('description= ?');  values.push(description); }

    // 2) Handle image update or deletion
    if (imageName) {
      updates.push('image = ?');
      values.push(imageName);
    } else if (deleteImage === 'true') {
      updates.push('image = NULL');
    }

    // 3) Ensure at least one field is updated
    if (updates.length === 0) {
      return res.status(400).json({ message: 'No update data provided.' });
    }

    // 4) Execute update
    const sql = `UPDATE events SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);
    conn.query(sql, values, (err, result) => {
      if (err) {
        console.error('Error updating event:', err);
        return res.status(500).json({ message: 'Update failed.' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Event not found.' });
      }
      res.json({ message: 'Event updated successfully.' });
    });

  } catch (err) {
    console.error('Unhandled error in PUT /api/events/:id:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── DELETE /api/events/:id ─────────────────────────────────
// Delete an event by ID
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    conn.query('DELETE FROM events WHERE id = ?', [id], (err, result) => {
      if (err) {
        console.error('Error deleting event:', err);
        return res.status(500).json({ message: 'Delete failed.' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Event not found.' });
      }
      res.json({ message: 'Event deleted successfully.' });
    });
  } catch (err) {
    console.error('Unhandled error in DELETE /api/events/:id:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const conn = require('../models/db');

// Create Event
router.post('/api/events', (req, res) => {
  const { title, description, date, created_by } = req.body;
  const sql = 'INSERT INTO events (title, description, event_date, created_by) VALUES (?, ?, ?, ?)';
  conn.query(sql, [title, description, date, created_by], (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    res.status(200).json({ message: 'Event created successfully' });
  });
});

// Get Events
router.get('/api/events', (req, res) => {
  conn.query('SELECT * FROM events ORDER BY event_date ASC', (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    res.status(200).json(results);
  });
});

// Delete Event
router.delete('/api/events/:id', (req, res) => {
  conn.query('DELETE FROM events WHERE id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json({ message: 'Failed to delete event' });
    res.status(200).json({ message: 'Event deleted' });
  });
});

module.exports = router;
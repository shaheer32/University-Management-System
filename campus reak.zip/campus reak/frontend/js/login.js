const loginForm = document.getElementById('loginForm');

loginForm?.addEventListener('submit', async e => {
  e.preventDefault();
  clearMsg();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value.toLowerCase();

  if (!email || !password || !role) {
    return showMsg('⚠️ Please fill out all fields.', 'danger');
  }

  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, role })
    });

    const data = await res.json();

    if (res.ok && data.role) {
      showMsg('✅ Login successful! Redirecting…', 'success');
      setTimeout(() => {
        window.location.href = data.role === 'admin'
          ? '/admin-dashboard.html'
          : '/student-dashboard.html';
      }, 800);
    } else {
      showMsg(data.message || '❌ Invalid credentials.', 'danger');
    }
  } catch (err) {
    console.error(err);
    showMsg('❌ Server error.', 'danger');
  }
});

function showMsg(msg, type) {
  clearMsg();
  const div = document.createElement('div');
  div.className = `alert alert-${type} mt-2 text-center`;
  div.textContent = msg;
  loginForm.appendChild(div);
}

function clearMsg() {
  const old = loginForm.querySelector('.alert');
  if (old) old.remove();
}

// js/register.js

// ► Handle Register form submission
document.getElementById('registerForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  clearRegisterMessage();

  // 1) Read inputs
  const name     = document.getElementById('name').value.trim();
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const confirm  = document.getElementById('confirm').value;
  const role     = document.getElementById('role').value;

  // 2) Front-end validation
  if (!name || !email || !password || !confirm || !role) {
    return showRegisterMessage('⚠️ Please fill out all fields.', 'danger');
  }
  if (!email.endsWith('@gmail.com')) {
    return showRegisterMessage('❌ Email must end with @gmail.com.', 'danger');
  }
  if (password.length < 8) {
    return showRegisterMessage('❌ Password must be at least 8 characters.', 'danger');
  }
  if (password !== confirm) {
    return showRegisterMessage('❌ Passwords do not match.', 'danger');
  }

  try {
    // 3) Send registration request
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role })
    });
    const data = await res.json();

    // 4) Handle responses
    if (res.ok) {
      showRegisterMessage('✅ Registration successful! Redirecting to login…', 'success');
      setTimeout(() => window.location.href = 'index.html', 1500);
    } else if (res.status === 409) {
      showRegisterMessage('❌ That email is already registered.', 'danger');
    } else {
      showRegisterMessage(data.message || '❌ Registration failed.', 'danger');
    }
  } catch (err) {
    console.error('Registration error:', err);
    showRegisterMessage('❌ Server error. Please try again later.', 'danger');
  }
});

// ► Show a Bootstrap alert below the form
function showRegisterMessage(msg, type) {
  clearRegisterMessage();
  const form = document.getElementById('registerForm');
  const div  = document.createElement('div');
  div.className = `alert alert-${type} mt-3 text-center`;
  div.textContent = msg;
  form.appendChild(div);
}

// ► Remove existing alert
function clearRegisterMessage() {
  const form = document.getElementById('registerForm');
  const old  = form.querySelector('.alert');
  if (old) old.remove();
}

// ► Show/Hide Password Toggle
document.getElementById('showPassword').addEventListener('change', function () {
  const pw = document.getElementById('password');
  const cp = document.getElementById('confirm');
  const type = this.checked ? 'text' : 'password';
  pw.type = type;
  cp.type = type;
});

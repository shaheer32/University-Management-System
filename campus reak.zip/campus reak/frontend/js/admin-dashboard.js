// admin-dashboard.js

document.addEventListener('DOMContentLoaded', () => {
  // ─── Back to Top logic ───
  const backBtn = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 200) backBtn.style.display = 'block';
    else backBtn.style.display = 'none';
  });
  backBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Utility: safe get element by ID
  function safeGet(id) {
    return document.getElementById(id);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Section toggling (hide all, show one)
  function showSection(sectionId) {
    ['createEventSection','viewEventsSection','studentRegistrationsSection','successMsg']
      .forEach(id => {
        const el = safeGet(id);
        if (el) el.classList.add('d-none');
      });
    const section = safeGet(sectionId);
    if (section) section.classList.remove('d-none');
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Success message helper
  function showSuccess(msg) {
    const box = safeGet('successMsg');
    if (!box) return;
    box.textContent = msg;
    box.classList.remove('d-none');
    setTimeout(() => box.classList.add('d-none'), 3000);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Create Event form
  safeGet('eventForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const formData = new FormData(safeGet('eventForm'));
    try {
      const res = await fetch('/api/events', { method:'POST', body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed creating event');
      showSuccess('✅ Event created successfully!');
      safeGet('eventForm').reset();
      loadEvents();
    } catch (err) {
      alert('Error: ' + err.message);
    }
  });

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Load and render all events
  async function loadEvents() {
    try {
      const res = await fetch('/api/events');
      const events = await res.json();
      const now = Date.now();
      const container = safeGet('eventList');
      if (!container) return;
      container.innerHTML = '';
      events.forEach(ev => {
        const expired = new Date(ev.end_date) < now;
        const imgTag = ev.image
          ? `<img src="/uploads/${ev.image}" class="event-thumbnail" alt="${ev.event_name}" />`
          : '';
        const editBtn = `
          <button data-action="edit"
                  data-id="${ev.id}"
                  data-name="${ev.event_name}"
                  data-desc="${ev.description}"
                  data-sd="${ev.start_date}"
                  data-ed="${ev.end_date}"
                  data-st="${ev.start_time}"
                  data-et="${ev.end_time}"
                  data-vn="${ev.venue}"
                  data-img="${ev.image || ''}"
                  class="btn btn-sm btn-outline-primary">
            Edit
          </button>`;
        const deleteBtn = `
          <button data-action="delete" data-id="${ev.id}"
                  class="btn btn-sm btn-outline-danger">
            Delete
          </button>`;
        const card = document.createElement('div');
        card.className = 'event-card';
        card.innerHTML = `
          ${imgTag}
          <div class="event-details">
            <h5>${ev.event_name} ${expired?'<span class="badge bg-secondary">Expired</span>':''}</h5>
            <p><strong>Start:</strong> ${ev.start_date} ${ev.start_time}</p>
            <p><strong>End:</strong>   ${ev.end_date} ${ev.end_time}</p>
            <p><strong>Venue:</strong> ${ev.venue}</p>
            <p>${ev.description}</p>
            <div class="d-flex justify-content-end gap-2">
              ${editBtn}
              ${deleteBtn}
            </div>
          </div>
        `;
        container.appendChild(card);
      });
    } catch (err) {
      console.error('Failed loading events', err);
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Variables for edit-image logic and delete-modal instance
  let deleteImageFlag = false;
  let deleteModalInstance = null;

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Delegate edit/delete button clicks
  document.body.addEventListener('click', e => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const action = btn.getAttribute('data-action');
    const id     = btn.getAttribute('data-id');

    if (action === 'edit') {
      deleteImageFlag = false;
      safeGet('editEventId').value     = id;
      safeGet('editTitle').value       = btn.dataset.name;
      safeGet('editDescription').value = btn.dataset.desc;
      safeGet('editStartDate').value   = btn.dataset.sd;
      safeGet('editEndDate').value     = btn.dataset.ed;
      safeGet('editStartTime').value   = btn.dataset.st;
      safeGet('editEndTime').value     = btn.dataset.et;
      safeGet('editVenue').value       = btn.dataset.vn;

      const imgContainer = safeGet('currentImageContainer');
      imgContainer.innerHTML = '';
      if (btn.dataset.img) {
        const img = document.createElement('img');
        img.src = `/uploads/${btn.dataset.img}`;
        img.className = 'img-preview';
        const trash = document.createElement('span');
        trash.className = 'trash-icon';
        trash.textContent = '🗑';
        trash.title = 'Remove this image';
        trash.addEventListener('click', () => {
          deleteImageFlag = true;
          imgContainer.innerHTML = '';
          safeGet('imageInput').value = '';
        });
        imgContainer.appendChild(img);
        imgContainer.appendChild(trash);
      }

      new bootstrap.Modal(safeGet('editModal')).show();
    }

    if (action === 'delete') {
      safeGet('deleteEventId').value = id;
      deleteModalInstance = new bootstrap.Modal(safeGet('deleteModal'));
      deleteModalInstance.show();
    }
  });

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Edit-Form submission
  safeGet('editForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const form      = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;

    const formData = new FormData(form);
    const id       = formData.get('id');

    if (deleteImageFlag) {
      formData.append('deleteImage', 'true');
    }
    const fileInput = safeGet('imageInput');
    if (fileInput && fileInput.files.length) {
      formData.append('image', fileInput.files[0]);
    }

    try {
      const res = await fetch(`/api/events/${id}`, {
        method: 'PUT',
        body: formData
      });
      const ct = res.headers.get('content-type') || '';
      let data;
      if (ct.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(text.replace(/<[^>]+>/g,'').trim() || 'Server error');
      }
      if (!res.ok) throw new Error(data.message || 'Update failed');

      bootstrap.Modal.getInstance(safeGet('editModal')).hide();
      loadEvents();
      showSuccess('✅ Event updated successfully!');
    } catch (err) {
      console.error('Update failed:', err);
      alert('Update failed: ' + err.message);
    } finally {
      submitBtn.disabled = false;
    }
  });

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Confirm delete
  safeGet('confirmDeleteBtn')?.addEventListener('click', async () => {
    const id = safeGet('deleteEventId').value;
    try {
      const res = await fetch(`/api/events/${id}`, { method:'DELETE' });
      if (!res.ok) throw new Error('Delete failed: ' + res.status);

      if (deleteModalInstance) {
        deleteModalInstance.hide();
      }
      document.body.classList.remove('modal-open');
      document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());

      loadEvents();
      showSuccess('🗑️ Event deleted successfully!');
    } catch (err) {
      console.error('Delete error:', err);
      alert('Delete error: ' + err.message);
    }
  });

// ──────────────────────────────────────────────────────────────────────────
// ✅ Student registrations list
async function loadStudentRegistrations() {
  const container = safeGet('studentList');
  if (!container) return;
  container.textContent = 'Loading...';
  try {
    const res = await fetch('/api/student/registrations');
    if (!res.ok) throw await res.json();
    const students = await res.json();
    if (!students.length) {
      container.innerHTML = '<p class="text-muted">No registrations yet.</p>';
      return;
    }
    container.innerHTML = '';

    students.forEach(s => {
      // naya card banao aur vertical layout do
      const d = document.createElement('div');
      d.className = 'registration-card p-3 mb-3';

      d.innerHTML = `
        <h6 class="student-name mb-2">${s.student_name}</h6>
        <p class="mb-1"><strong>Event:</strong> ${s.event_title}</p>
        <p class="mb-1"><strong>Email:</strong> ${s.email}</p>
        <p class="mb-1"><strong>Phone:</strong> ${s.phone}</p>
        <p class="mb-1"><strong>Dept:</strong> ${s.department}</p>
        <p class="mb-1"><strong>Roll:</strong> ${s.roll_no}</p>
        <p class="mb-1"><strong>Gender:</strong> ${s.gender}</p>
        <p class="mb-2"><strong>Age:</strong> ${s.age}</p>
        <select class="status-select mb-0" data-stu-id="${s.id}">
          <option value="Pending">Pending</option>
          <option value="Approved">Approved</option>
          <option value="Denied">Denied</option>
        </select>
      `;

      const sel = d.querySelector('select');
      sel.value = s.status;
      sel.classList.add(`status-${s.status.toLowerCase()}`);

      container.appendChild(d);
    });
  } catch (err) {
    container.innerHTML = `<p class="text-danger">Failed: ${err.message||''}</p>`;
    console.error(err);
  }
}

// ──────────────────────────────────────────────────────────────────────────
// ✅ Delegate status change
document.body.addEventListener('change', async e => {
  const sel = e.target.closest('select.status-select');
  if (!sel) return;
  const id     = sel.dataset.stuId;
  const status = sel.value;

  // pehle purani classes hatao
  sel.classList.remove('status-pending','status-approved','status-denied');
  // nayi status ki class add karo
  sel.classList.add(`status-${status.toLowerCase()}`);

  try {
    const res = await fetch(`/api/student/registrations/${id}`, {
      method:'PUT',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ status })
    });
    if (!res.ok) throw await res.json();
    showSuccess(`Status updated to ${status}`);
  } catch (err) {
    alert('Status update failed: ' + (err.message||''));
  }
});

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Sidebar navigation
  safeGet('dashboardNav')?.addEventListener('click', () => showSection('createEventSection'));
  safeGet('viewEventNav')?.addEventListener('click', () => { showSection('viewEventsSection'); loadEvents(); });
  safeGet('studentRegistrationsNav')?.addEventListener('click', () => { showSection('studentRegistrationsSection'); loadStudentRegistrations(); });

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Fetch admin name & initial load
  (async () => {
    try {
      const me = await (await fetch('/api/me')).json();
      safeGet('adminName').textContent = me.name || 'Admin';
    } catch {}
    showSection('createEventSection');
    loadEvents();
  })();

  // ──────────────────────────────────────────────────────────────────────────
  // ✅ Logout
  safeGet('logoutBtn')?.addEventListener('click', () => {
    fetch('/api/logout', { method:'POST' }).then(_=> location.href = '/');
  });
});

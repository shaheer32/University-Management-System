/* ✅ Format full date & time (e.g., Wed, Jul 10, 2025, 03:30 PM) */
function formatDate(iso) {
  return new Date(iso).toLocaleString('en-US', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
}

// ✅ Format only time (e.g., 03:30 PM)
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
}

// ✅ Toggle dropdown menu visibility
function toggleDropdown() {
  document.getElementById('dropdownMenu').classList.toggle('show');
}

// ✅ Open registration modal and set event ID
function openRegistrationForm(eventId) {
  const form = document.getElementById('eventRegistrationForm');
  form.reset();
  document.getElementById('eventIdHidden').value = eventId;
  document.getElementById('registrationForm').style.display = 'flex';
}

// ✅ Close registration modal
function closeForm() {
  document.getElementById('registrationForm').style.display = 'none';
}

// ✅ Load and display student name in header and dropdown
async function loadStudentName() {
  try {
    const res = await fetch('/api/me');
    const data = await res.json();
    document.getElementById('studentName').textContent = data.name;
    document.getElementById('dropdownName').textContent = data.name;
  } catch (err) {
    console.error('Error loading student name:', err);
  }
}

// ✅ Fetch events from API and render event cards
async function loadEvents() {
  try {
    const res = await fetch('/api/events');
    const events = await res.json();
    console.log('Fetched events:', events);

    const container = document.getElementById('eventList');
    container.innerHTML = '';

    events.forEach(event => {
      const card = document.createElement('div');
      card.className = 'event-card';

      card.innerHTML = `
        ${event.image ? `<img src="/uploads/${event.image}" alt="${event.event_name}" />` : ''}
        <div class="event-body">
          <h4>${event.event_name}</h4>
          <p><strong>Venue:</strong> ${event.venue || 'N/A'}</p>
          <p><strong>Start:</strong> ${formatDate(event.start_date)}</p>
          <p><strong>End:</strong> ${formatDate(event.end_date)}</p>
          <p>${event.description}</p>
          <button onclick="openRegistrationForm(${event.id})" class="btn-register">Register</button>
        </div>
      `;

      container.appendChild(card);
    });
  } catch (err) {
    console.error('Error loading events:', err);
  }
}

// ✅ Handle registration form submission
async function submitRegistration(e) {
  e.preventDefault();
  const formObject = {};
  new FormData(this).forEach((value, key) => formObject[key] = value);

  try {
    const res = await fetch('/api/student/register-event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formObject)
    });
    const result = await res.json();
    alert(result.message);
    closeForm();
  } catch (err) {
    console.error('Error submitting registration:', err);
    alert('Submission failed. Please try again.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadStudentName();
  loadEvents();
  document.getElementById('eventRegistrationForm').addEventListener('submit', submitRegistration);
});

// ✅ Logout student
function logout() {
  fetch('/api/logout', { method: 'POST' })
    .then(() => window.location.href = '/')
    .catch(err => {
      console.error('Logout failed:', err);
      alert('Logout failed.');
    });
}

// ✅ Show student's registrations in a modal
async function showMyRegistrations() {
  try {
    const res = await fetch('/api/student/my-registrations');
    if (!res.ok) throw new Error('Failed to fetch registrations');
    const registrations = await res.json();

    const tbody = document.getElementById('registrationsBody');
    tbody.innerHTML = '';

    if (registrations.length === 0) {
      tbody.innerHTML = `
        <tr><td colspan="5" class="no-data">No registrations found.</td></tr>
      `;
    } else {
      registrations.forEach(reg => {
        const statusColor = reg.status === 'Approved' ? 'green' : (reg.status === 'Denied' ? 'red' : 'gray');
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${reg.event_name || reg.event_title}</td>
          <td>${formatDate(reg.start_date)}</td>
          <td>${formatDate(reg.end_date)}</td>
          <td class="status" style="color:${statusColor};">${reg.status}</td>
          <td>${formatDate(reg.registered_at)}</td>
        `;
        tbody.appendChild(tr);
      });
    }

    document.getElementById('myRegistrationsOverlay').style.display = 'flex';
  } catch (err) {
    console.error('Could not load registrations:', err);
    alert('Unable to load registrations.');
  }
}

// ✅ Close registrations modal
function closeRegistrations() {
  document.getElementById('myRegistrationsOverlay').style.display = 'none';
}

 create database EventManagement;
USE EventManagement;
select * from users;

CREATE TABLE  users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,  -- Plain text for now
  role ENUM('admin', 'student') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);













CREATE TABLE student_registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  department VARCHAR(100) NOT NULL,
  roll_no VARCHAR(50) NOT NULL,
  age INT NOT NULL,
  gender VARCHAR(10) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  event_id INT,
  status ENUM('Pending', 'Approved', 'Denied') DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);
select * from student_registrations;
select * from users;
ALTER TABLE events
  ADD COLUMN venue       VARCHAR(255) NOT NULL DEFAULT '',
  ADD COLUMN start_time  TIME             NOT NULL,
  ADD COLUMN end_time    TIME             NOT NULL;
  
  


INSERT INTO users (name, email, password, role)
VALUES (
  'Ali Login Test',
  'admin@campus.com',
  '$2b$10$J3bfSP.r7Wqx9cGSRVDKeOt.Tkz5P0bJ62aYYRSKKHEeQSc4Zq5c2',
  'admin'
);

drop table users;